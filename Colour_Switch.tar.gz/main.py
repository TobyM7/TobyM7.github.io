import pygame
from sys import exit
import Dodge
import time
import os
import match 
white=(255, 255, 255)
black=(0, 0, 0)
gray=(50, 50, 50)
red=(255, 0, 0)
green=(0, 255, 0)
blue=(0, 0, 255)
yellow=(255, 255, 0)
green=(0,255,0)

font = 'Chewy-Regular.ttf'
width = 600
height = 800
pygame.init()
screen = pygame.display.set_mode((width,height))
clock = pygame.time.Clock()
class Button(pygame.sprite.Sprite):
    def __init__(self, x, y, colour):
        # Call the parent class (Sprite) constructor
        super().__init__()
        
        self.image = pygame.Surface((190, 90))
        self.image.fill(colour)
        
        
        self.rect = self.image.get_rect(topleft=(x, y))
        
        
        self.clicked = False
        
        
        
        
        

def run():   
    font = "Chewy-Regular.ttf"
    width = 600
    height = 650
    os.environ['SDL_VIDEO_CENTERED'] = '1'
    screen = pygame.display.set_mode((width,height))
    clock = pygame.time.Clock()
    font = "Chewy-Regular.ttf"
    def text_format(message, textFont, textSize, textColor):
        newFont=pygame.font.Font(textFont, textSize)
        newText=newFont.render(message, 0, textColor)
        return newText                 
    B1 = Button(50, 500, (0,255,0))
    B2 = Button(375, 500, (255,0,0))
    button_group = pygame.sprite.Group(B1, B2)
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                    
                    if B1.rect.collidepoint(event.pos):
                        Dodge.run()
                        time.sleep(0.5)
                        screen = pygame.display.set_mode((width,height))
                        
                    if B2.rect.collidepoint(event.pos):
                        match.run()
                        time.sleep(0.5)
                        screen = pygame.display.set_mode((width,height))


            
        title=text_format("SPACE IS THE KEY", font, 90, (255,255,255))
        title_rect=title.get_rect()
        
        screen.blit(title, (width/2 - (title_rect[2]/2), 80))
        under=text_format("Space to Play", font, 60, (255,255,255))
        under_rect=under.get_rect()
        
        
        
        
        button_group.update()
        button_group.draw(screen)
        
        screen.blit(under, (width/2 - (under_rect[2]/2), 200))
        T1=text_format("1", font, 70, (255,255,255))
        T1_rect=T1.get_rect()
        
        screen.blit(T1, (135, 500))
        T2=text_format("2", font, 70, (255,255,255))
        T2_rect=T2.get_rect()
        screen.blit(T2, (455, 500))
        
        pygame.display.update()
        clock.tick(60)

if __name__ == "__main__":
    run()