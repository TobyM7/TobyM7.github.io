import pygame
import random
import os
# define colors
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)

# game settings
WIDTH = 600
HEIGHT = 400
FPS = 60

# create window
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Press Space to Avoid Falling Enemies")
clock = pygame.time.Clock()

class Player():
    def __init__(self, x, y, width, height, speed):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = speed

    def move(self, x, y):
        self.x = x
        self.y = y

class Enemy():
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
def run():
    os.environ['SDL_VIDEO_CENTERED'] = '1'
    # define colors
    BLACK = (0, 0, 0)
    GREEN = (0, 255, 0)
    RED = (255, 0, 0)
    # game settings
    WIDTH = 600
    HEIGHT = 400
    FPS = 60

    # create window
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Press Space to Avoid Falling Enemies")
    clock = pygame.time.Clock()
    speed = 5
    score = 0
    space = True
    pos1x = 200 
    pos1y = 350
    pos2x = 400
    pos2y = 350 
    # define player
    player = Player(pos1x, pos1y, 30, 30, 3)
    enemy = Enemy(400, 0, 30, 30)
    # define enemies
    enemies = []

    # game loop
    running = True
    while running:
        # keep loop running at the right speed
        clock.tick(FPS)

        # events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if space:
                        player.move(pos1x, pos1y)
                        space = False
                        
                    elif not space:
                        player.move(pos2x, pos2y)
                        space = True
                        
        # check for key presses
        
            
                

                

        # update
        # update enemies
        for enemy in enemies:
            enemy.y += speed
            if enemy.y > HEIGHT:
                enemies.remove(enemy)
                score += 1
                speed += 0.1

        # spawn enemies
        if len(enemies) < 1:
            x = 0
            col = random.randint(0, 1)
            rand = random.randint(1, 2)
            
            if rand == 1:
                x = 400
            if rand == 2:
                x = 200
            
            
            y = 0
            enemies.append(Enemy(x, y, 30, 30))
            
        
        # check collisions
        for enemy in enemies:
            if player.x < enemy.x + enemy.width and player.x + player.width > enemy.x:
                if player.y < enemy.y + enemy.height and player.y + player.height > enemy.y:
                    running = False

        # draw
        screen.fill(BLACK)
        pygame.draw.rect(screen, RED, (player.x, player.y, player.width, player.height))
        for enemy in enemies:
            pygame.draw.rect(screen, GREEN, (enemy.x, enemy.y, enemy.width, enemy.height))
        font = pygame.font.Font('freesansbold.ttf', 32)
        text = font.render("Score: " + str(score), True, GREEN)
        screen.blit(text, (WIDTH - 150, 10))

        # after drawing everything, flip the display
        pygame.display.flip()
        
