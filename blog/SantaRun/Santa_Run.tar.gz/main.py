import Main_code as MC
import menu as M
if __name__ == '__main__': #* if this is the main file 
    Photo = M.Menu("Start","Quit", "More Info", "Hellllo", True)
    MC.Run(Photo)

