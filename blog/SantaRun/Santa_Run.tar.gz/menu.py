import os
import pygame
import more_Info as MI
import sys  
from time import sleep
import Main_code as MC
vec = pygame.math.Vector2


pygame.init()


os.environ['SDL_VIDEO_CENTERED'] = '1' #*centre


screen_width=800
screen_height=600
screen=pygame.display.set_mode((screen_width, screen_height))


def text_format(message, textFont, textSize, textColor):
    newFont=pygame.font.Font(textFont, textSize)
    newText=newFont.render(message, 0, textColor)

    return newText




# Colors
white=(255, 255, 255)
black=(0, 0, 0)
gray=(50, 50, 50)
red=(255, 0, 0)
green=(0, 255, 0)
blue=(0, 0, 255)
yellow=(255, 255, 0)
green=(0,255,0)

font = "Chewy-Regular.ttf"



clock = pygame.time.Clock()
FPS=60

class Button(pygame.sprite.Sprite):
    def __init__(self, x, y):
        # Call the parent class (Sprite) constructor
        super().__init__()
        
        self.image = pygame.image.load("tick.png")
        self.image = pygame.transform.scale(self.image,(40,40)) 
        
        self.rect = self.image.get_rect(topleft=(x, y))
        
        
        self.clicked = False
        
        
        self.font = pygame.font.Font(font, 64)
    
    def update(self):
        
        if self.clicked:
            self.image = pygame.image.load("tick.png")
            self.image = pygame.transform.scale(self.image,(40,40)) 
        
        else:
            self.image = pygame.image.load("cross.png") 
            self.image = pygame.transform.scale(self.image,(40,40))

def Menu(Top, Middle, Bottom, score, End):
    screen_width=800
    screen_height=600
    screen=pygame.display.set_mode((screen_width, screen_height))
    
    # Create a Button object and add it to a sprite group
    button = Button(740, 20)
    button_group = pygame.sprite.Group(button)
    
    # Set the window to be centered on the screen
    os.environ['SDL_VIDEO_CENTERED'] = '1'

    # Initialize the menu loop
    menu=True
    selected=Top

    while menu:
        for event in pygame.event.get():
            # If the user clicks the close button, quit the game
            if event.type==pygame.QUIT:
                pygame.quit()
                quit()
                
            # If the user clicks the mouse button, toggle the button's clicked attribute
            # and update the text displayed on the button
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button.rect.collidepoint(event.pos):
                    button.clicked = not button.clicked  
                    photo = button.clicked 
                        
                    if photo:
                        text = button.font.render("Graphics enabled", True, (0,0,0))
                    if not photo:
                        text = button.font.render("Graphics disabled", True, (0,0,0))

                    # Center the text on the button
                    text_rect = text.get_rect()
                    text_rect.center = (screen_width/2, screen_height - 380)

                    # Draw the text on the screen
                    screen.blit(text, text_rect)
                    pygame.display.flip()
                    pygame.time.delay(1000)
            
            # If the user presses a key, update the selected option
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_UP and selected==Top :
                    selected=Bottom
                elif event.key==pygame.K_UP and selected==Bottom :
                    selected=Middle
                elif event.key==pygame.K_UP and selected==Middle :
                    selected=Top
                if event.key==pygame.K_DOWN and selected==Top :
                    selected=Middle
                elif event.key==pygame.K_DOWN and selected==Bottom :
                    selected=Top
                elif event.key==pygame.K_DOWN and selected==Middle :
                    selected=Bottom
                    
                # If the user presses the Return key, take the appropriate action based on the selected option
                if event.key==pygame.K_RETURN:
                    if selected==Top and End == True:
                        return button.clicked 
                        menu = False
                            
                    if selected==Middle:
                        pygame.quit()
                        quit()
                    
                    if selected==Bottom and End == True:
                        MI.Run()
                    if selected==Bottom and End == False:
                        MC.Run(button.clicked)

                    
                    
        # Main Menu UI
        screen.fill(red)
        Score = text_format(score.upper(), font, 75, black) 
        title=text_format("Santa Run", font, 90, green)
        if selected==Top:
            text_start=text_format(Top.upper(), font, 75, white)
        else:
            text_start = text_format(Top.upper(), font, 75, black)
        if selected==Middle:
            text_quit=text_format(Middle.upper(), font, 75, white)
        else:
            text_quit = text_format(Middle.upper(), font, 75, black)
        if selected==Bottom:
            text_info=text_format(Bottom.upper(), font, 75, white)
        else:
            text_info = text_format(Bottom.upper(), font, 75, black)

        score_rect = Score.get_rect()
        title_rect=title.get_rect()
        start_rect=text_start.get_rect()
        quit_rect=text_quit.get_rect()
        info_rect=text_info.get_rect()
        
        if End == False:
            screen.blit(Score, (screen_width/2 - (score_rect[2]/2), 220))
        screen.blit(title, (screen_width/2 - (title_rect[2]/2), 80))
        screen.blit(text_start, (screen_width/2 - (start_rect[2]/2), 300))
        screen.blit(text_quit, (screen_width/2 - (quit_rect[2]/2), 360))
        screen.blit(text_info, (screen_width/2 - (info_rect[2]/2), 420))
        button_group.update()
        button_group.draw(screen)
        pygame.display.update()
        
        clock.tick(FPS)


