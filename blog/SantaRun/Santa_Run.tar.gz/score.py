def highScore(Score):
    
    fin = open('score.txt', 'rt' ) #* open file

    P = int(fin.read()) #*read file

    
    if P < Score:
        
        fout = open('score.txt', 'wt' ) #* add new score if it is greater that highscore
        fout.write(str(Score))
        fout.close()
    return P


