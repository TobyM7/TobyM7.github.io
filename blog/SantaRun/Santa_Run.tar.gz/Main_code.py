
import os
import sys
import pygame
import random
import time
import menu as M
import score 



os.environ['SDL_VIDEO_CENTERED'] = '1'
#Initialize the Game

height = 600
width = 400
ACC = 0.5
FRIC = -0.12
FPS = 60

vec = pygame.math.Vector2
FramePerSecond = pygame.time.Clock()

displaySurface = pygame.display.set_mode((width, height))
gold=(165,165,42)
white=(255, 255, 255)
black=(0, 0, 0)
gray=(50, 50, 50)
red=(255, 0, 0)
green=(0, 255, 0)
blue=(0, 0, 255)
yellow=(255, 255, 0)
silver = (128,128,128)
brown=(128,70,27)

def display():
    
    displaySurface = pygame.display.set_mode((width, height))
    
class Player(pygame.sprite.Sprite):
    def __init__(self, image="Player1.png", nb=1, photo=True):  # set color and number
        super().__init__()
        if photo == True:
            self.image = pygame.image.load(image)
            self.image = pygame.transform.scale(self.image,(50,50))
            self.rect = self.image.get_rect()
        if photo == False:
            self.image = pygame.Surface((30, 30))
            self.image.fill(green)
            self.rect = self.image.get_rect()
        
        self.pos = vec(10, height - 50)  # set pos etc
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        self.jumping = False
        self.score = 0
        self.nb = nb
        self.directionP1 = 0
        self.directionP2 = 0
    def move(self):

        
        self.acc = vec(0, 0.5)

        if self.nb == 1:
            if pygame.key.get_pressed()[pygame.K_LEFT]:  # move 1
                self.acc.x = -ACC
                if self.directionP1 == 1:
                    self.directionP1 = 0
                    self.image = pygame.transform.flip(self.image, 1, 0)
            elif pygame.key.get_pressed()[pygame.K_RIGHT]:
                self.acc.x = ACC
                if self.directionP1 == 0:
                    self.image = pygame.transform.flip(self.image, 1, 0)
                    self.directionP1 = 1

        if self.nb == 2:
            if pygame.key.get_pressed()[pygame.K_a]:  # move 2
                self.acc.x = -ACC
                if self.directionP1 == 1:
                    self.directionP1 = 0
                    self.image = pygame.transform.flip(self.image, 1, 0)
            elif pygame.key.get_pressed()[pygame.K_d]:
                self.acc.x = ACC
                if self.directionP1 == 0:
                    self.image = pygame.transform.flip(self.image, 1, 0)
                    self.directionP1 = 1

        self.acc.x += self.vel.x * FRIC  # calculate movement
        self.vel += self.acc
        self.pos += self.vel + 0.5 * self.acc

        if self.pos.x > width:
            self.pos.x = 0
            self.score += 2
        if self.pos.x < 0:
            self.score += 2
            self.pos.x = width

        self.rect.midbottom = self.pos


    def jump(self, Y, platforms):
        hits = pygame.sprite.spritecollide(self, platforms, False)
        if hits:
            self.jumping = True
            self.vel.y = -Y  # jumping

    def update(self, platforms):
        hits = pygame.sprite.spritecollide(self, platforms, False)
        if hits and self.vel.y > 0:
            if self.rect.y < hits[0].rect.bottom:  # update sprites
                self.pos.y = hits[0].rect.top + 1
                self.vel.y = 0
                self.jumping = False
                

                        

                
            

                
            
            
                

                

class Spring(pygame.sprite.Sprite):
    
    def __init__(self, pos, photo):
        super().__init__()
        if photo == True:
            self.image = pygame.image.load("spring.png")
            self.image = pygame.transform.scale(self.image,(40,40))
            self.rect = self.image.get_rect()
        if photo == False:
            self.image = pygame.Surface((30, 30))
            self.image.fill(silver)
            self.rect = self.image.get_rect()
        self.rect.topleft = pos

    def update(self, P1, P2, death):
        
        if self.rect.colliderect(P1.rect):
            
            P1.vel.y = -30
            
            
            
            self.kill()
            death = False
        if self.rect.colliderect(P2.rect):
            P2.vel.y = -30
            
            self.kill()
            death = False
        return death

class Coin(pygame.sprite.Sprite):
    def __init__(self, pos, photo):
        super().__init__()
        if photo == True:
            self.image = pygame.image.load("present.png")
            self.image = pygame.transform.scale(self.image,(40,40))
            self.rect = self.image.get_rect()
        if photo == False:
            self.image = pygame.Surface((30, 30))
            self.image.fill(gold)
            self.rect = self.image.get_rect()

        self.rect.topleft = pos

    def update(self, P1, P2):
        if self.rect.colliderect(P1.rect):
            P1.score += 20
            self.kill()
        if self.rect.colliderect(P2.rect):
            P1.score += 20
            self.kill()
class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos, photo):
        super().__init__()
        if photo == True:
            self.image = pygame.image.load("Enemy.png")
            self.image = pygame.transform.scale(self.image,(75,50))
            self.rect = self.image.get_rect()
        if photo == False:
            
            self.image = pygame.Surface((30, 30))
            self.image.fill(red)
            self.rect = self.image.get_rect()
        self.moving = True
        self.speed = 1
        self.point = True
        self.rect.topleft = pos

    def update(self, P1, P2, dif, death):
    
        if self.rect.colliderect(P1.rect) and death == True:
            
            
            P = score.highScore(P1.score)
            M.Menu(f"score was {P1.score}", "Quit",  "Play Again", f"high score is {P}", False)
            display()
        if self.rect.colliderect(P2.rect) and dif < 0 and death == True:
            
            P = score.highScore(P1.score)
            
            M.Menu(f"score was {P1.score}", "Quit",  "Play Again", f"high score is {P}", False)
            display()
        
    def move(self, screen_width):
        if self.moving == True:  # move
            
            self.rect.move_ip(self.speed, 0)

            if self.rect.right < 0:
                self.rect.right = screen_width
            elif self.rect.left > screen_width:
                self.rect.left = 0

                


class Platform(pygame.sprite.Sprite):
    def __init__(self, photo):
        super().__init__()
        if photo == True:
            self.image = pygame.image.load("Platform.png")
            self.image = pygame.transform.scale(self.image, (random.randint(50, 100), 20))  # pick random length
        if photo == False:
            self.image = pygame.Surface((random.randint(50, 100), 20))
            self.image.fill(brown)
            
        self.rect = self.image.get_rect(center=(random.randint(0, width - 10), random.randint(0, height - 30)))  # genarate platfroms
        self.moving = True
        self.speed = random.randint(-1, 1)
        self.point = True

    def move(self):
        if self.moving:  # move
            self.rect.move_ip(self.speed, 0)
            if self.speed > 0 and self.rect.right > width:
                self.speed = -self.speed
            elif self.speed < 0 and self.rect.left < 0:
                self.speed = -self.speed

            
                

    def generateExtra(self, coins, enemys, springs,  photo):
        gen = random.randint(1, 10)
        coin = False
        enemy = False
        spring = False
        
        if gen == 1 or gen == 2:
            coin = True
        if gen == 4 or gen == 5:
            enemy = True
        if gen == 6:
            spring = True
        
        if self.speed == 0 and coin == True:
            coins.add(Coin((self.rect.centerx - 10, self.rect.centery - 50), photo))
        if self.speed == 0 and enemy == True:
            enemys.add(Enemy((self.rect.centerx, self.rect.centery - 50), photo))
        if self.speed == 0 and spring == True:
            springs.add(Spring((self.rect.centerx - 10, self.rect.centery - 50), photo))
        


def check(platform, group):
    if pygame.sprite.spritecollideany(platform, group):
        return True

    for i in group:  # group = group of sprites
        if i == platform:
            continue
        if abs(platform.rect.top - i.rect.bottom) < 40 and abs(platform.rect.bottom - i.rect.top) < 40:
            return True
    return False


def Run(Photo):
    display()
    scroll_speed_x = 0
    scroll_speed_y = -1
    bg_image = pygame.image.load("background3.png")
    
    bg_image_rect = bg_image.get_rect()
    
    
    bg_x = 0
    bg_y = 0
    
    frame_count = 0
    frame_rate = 60
    start_time = 90
    
    def plat_gen(platforms, all_sprites):
        while len(platforms) < 12:
            WIDTH = random.randrange(50, 100)  # pick randomw width
            p = Platform(Photo)
            i = True

            while i:
                p = Platform(Photo)
                p.rect.center = (
                    random.randrange(0, width - WIDTH),
                    random.randrange(-50, 0),
                )
                i = check(p, platforms)
            
            p.generateExtra(coins, enemys, springs,  Photo)
            platforms.add(p)
            all_sprites.add(p)
    death = True
    timer = 0
    dif = -1
    difficulty = 0
    Jump = 20
    P1 = Player("Player1.png", 1, Photo)
    P2 = Player("player2.png", 2, Photo)  # insishalise p1 and p2

    PT1 = Platform(Photo)
    PT1.image = pygame.Surface((width, 20))
    PT1.image.fill((255, 0, 0))
    PT1.rect = PT1.image.get_rect(center=(width / 2, height - 10))
    PT1.moving = False
    PT1.point = False

    all_sprites = pygame.sprite.Group()  # make groups
    all_sprites.add(PT1)
    all_sprites.add(P2)
    all_sprites.add(P1)

    platforms = pygame.sprite.Group()  # make groups
    platforms.add(PT1)
    springs = pygame.sprite.Group()
    coins = pygame.sprite.Group()
    enemys = pygame.sprite.Group()
    
    Run = True
    for i in range(random.randint(10, 11)):
        j = True
        pl = Platform(Photo)
        while j:
            pl = Platform(Photo)
            j = check(pl, platforms)
        platforms.add(pl)
        all_sprites.add(pl)
        pl.generateExtra(coins, enemys, springs, Photo)
        
    while Run:
        total_seconds = frame_count // FPS
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        dt = total_seconds
        if Photo == True:
            if bg_x < -bg_image_rect.width:
                bg_x = 0
            if bg_y < -bg_image_rect.height:
                bg_y = 0
            displaySurface.blit(bg_image, (bg_x, bg_y))
        if Photo == False:
            displaySurface.fill(black)

        P1.update(platforms)
        P2.update(platforms)
        for event in pygame.event.get():  # set dificulty
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    P1.jump(Jump, platforms)
                if event.key == pygame.K_w:
                    P2.jump(Jump, platforms)
                if event.key == pygame.K_0:
                    P2.kill()
                    dif = 1
                if event.key == pygame.K_1:
                    P2.kill()
                    difficulty = 3
                    dif = 2
                if event.key == pygame.K_2:
                    P2.kill()
                    dif = 3
                    difficulty = 4
                if event.key == pygame.K_3:
                    P2.kill()
                    difficulty = 5
                    dif = 4
                if event.key == pygame.K_4:
                    P2.kill()
                    difficulty = 6
                    dif = 5
                if event.key == pygame.K_5:
                    P2.kill()
                    difficulty = 7
                    dif = 6
                
        if P1.pos.y < P2.pos.y:
            highestPlayer = P1
        else:
            highestPlayer = P2

        if difficulty == 0:
            if highestPlayer.pos.y <= height * 0.5:
                velocity = abs(highestPlayer.vel.y)
                P1.pos.y += velocity
                P2.pos.y += velocity
                for sprite in platforms:
                    sprite.rect.y += velocity
                    if sprite.rect.top > height:
                        sprite.kill()
                        P1.score += 1
                for sprite in coins:
                    sprite.rect.y += velocity
                    if sprite.rect.top > height:
                        sprite.kill()
                for sprite in enemys:
                    sprite.rect.y += velocity
                    if sprite.rect.top > height:
                        sprite.kill()
                for sprite in springs:
                    sprite.rect.y += velocity
                    if sprite.rect.top > height:
                        sprite.kill()
                

        elif difficulty >= 0:
            if timer >= FPS * 2:
                velocity = abs(difficulty)
                P1.pos.y += velocity
                for sprite in platforms:
                    sprite.rect.y += velocity
                    if sprite.rect.top > height:
                        sprite.kill()
                        P1.score += 1
                for sprite in coins:
                    sprite.rect.y += velocity
                    if sprite.rect.top >= height:
                        sprite.kill()
                for sprite in enemys:
                    sprite.rect.y += velocity
                    if sprite.rect.top >= height:
                        sprite.kill()
                for sprite in springs:
                    sprite.rect.y += velocity
                    if sprite.rect.top >= height:
                        sprite.kill()
                
            else:
                timer += 1

        
        plat_gen(platforms, all_sprites)
        if P1.score > 100:
            f = pygame.font.SysFont("Chewy", 60)  # blit text to screen
            g = f.render(str(P1.score), True, green)
            displaySurface.blit(g, (width / 2 - 20, 10))
        else:
            f = pygame.font.SysFont("Chewy", 60)  # blit text to screen
            g = f.render(str(P1.score), True, green)
            displaySurface.blit(g, (width / 2, 10))

        for entity in all_sprites:
            entity.move()
            displaySurface.blit(entity.image, entity.rect)  # move all spries and blit them

        for coin in coins:
            displaySurface.blit(coin.image, coin.rect)
            coin.update(P1, P2)
        for spring in springs:
            displaySurface.blit(spring.image, spring.rect)
            death = spring.update(P1, P2, death)
        
            
            
        for enemy in enemys:
            displaySurface.blit(enemy.image, enemy.rect)
            enemy.move(width)
            enemy.update(P1, P2, dif, death)
        

        total_seconds = frame_count // FPS
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        
        
        output_string = "{0:02}:{1:02}".format(minutes, seconds)
        if total_seconds % 2 == 0:
            death = True

        font = pygame.font.SysFont("Chewy", 60)  
        output = font.render(output_string, True, green)
        displaySurface.blit(output , (width * 0.39, 50))
    
    
    
    
        frame_count += 1
        
        if P1.rect.top > height or P2.rect.top > height:  # end game
            
            P = score.highScore(P1.score)
            
            M.Menu(f"score was {P1.score}", "Quit",  "Play Again", f"high score is {P}", False)
        
        
        pygame.display.update()
        FramePerSecond.tick(FPS)
        
