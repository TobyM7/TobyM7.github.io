import pygame
import sys
import os

os.environ['SDL_VIDEO_CENTERED'] = '1'

pygame.init()
def run():
    i = True
    #
    SCREEN_WIDTH = 800
    SCREEN_HEIGHT = 600
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    
    start_image = pygame.image.load("Extra Info.png")
    start_image = pygame.transform.scale(start_image,(800,600))
    
    font = pygame.font.Font(None, 36)

    
    message = "Press SPACE to exit"
    text = font.render(message, 1, (0, 0, 0))

    
    while i:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
            
                if event.key == pygame.K_SPACE:
                    i = False
                    
                    

        screen.blit(start_image, (0, 0))
        screen.blit(text, (SCREEN_HEIGHT / 2, 550))
        pygame.display.flip()

    
    screen.fill((0, 0, 0))
    pygame.display.flip()
